/* ==========================================================================
   MAIN APPLICATION STATE CONTROLLER & ROUTER WITH AUTH GUARD
   ========================================================================== */

import { api } from './api.js';
import { getStore, subscribeStore, exportTransactionsCSV, clearUserSession, fetchRemoteData } from './mockData.js';
import { bindChartInteractivity } from './components/SVGCharts.js';
import { renderModals, bindModalEvents } from './components/Modals.js';
import { renderLandingPage } from './views/LandingPage.js';
import { renderAuthPage, bindAuthEvents } from './views/AuthPage.js';
import { renderDashboardView } from './views/DashboardView.js';
import { renderExpensesView, bindExpensesEvents } from './views/ExpensesView.js';
import { renderBudgetPlannerView } from './views/BudgetPlannerView.js';
import { renderAnalyticsView } from './views/AnalyticsView.js';
import { renderSavingsGoalsView } from './views/SavingsGoalsView.js';
import { renderSettingsView, bindSettingsEvents } from './views/SettingsView.js';

// Determine initial route based on authentication state
let currentRoute = api.getToken() ? 'dashboard' : 'auth';

window.navigateTo = (route) => {
  // Guard protected routes: if no token exists, force auth page
  const protectedRoutes = ['dashboard', 'expenses', 'budget', 'analytics', 'savings', 'settings'];
  if (protectedRoutes.includes(route) && !api.getToken()) {
    currentRoute = 'auth';
  } else {
    currentRoute = route;
  }
  renderApp();
  window.scrollTo(0, 0);
};

window.exportCSV = () => {
  exportTransactionsCSV();
};

window.handleLogout = () => {
  clearUserSession();
  window.navigateTo('auth');
};

const renderSidebar = (activeRoute) => {
  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: '<path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>' },
    { id: 'expenses', label: 'Expenses', icon: '<rect x="1" y="4" width="22" height="16" rx="2" ry="2"/><line x1="1" y1="10" x2="23" y2="10"/>' },
    { id: 'budget', label: 'Budget Planner', icon: '<path d="M3 3v18h18"/><path d="M18 9l-5 5-4-4-3 3"/>' },
    { id: 'analytics', label: 'Analytics', icon: '<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>' },
    { id: 'savings', label: 'Savings Goals', icon: '<circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/>' },
    { id: 'settings', label: 'Settings', icon: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/>' }
  ];

  return `
    <aside class="sidebar">
      <div style="padding: 0.25rem 0.5rem 0.75rem 0.5rem; margin-bottom: 0.75rem; border-bottom: 1px solid var(--border-color); text-align: center;">
        <img src="assets/code_morphicx_logo.jpg" alt="Code Morphicx Logo" style="width: 64px; height: 64px; border-radius: 50%; object-fit: cover; box-shadow: var(--shadow-sm); border: 2px solid var(--primary-border);" />
        <div style="font-size: 0.65rem; font-weight: 800; color: var(--primary); letter-spacing: 0.05em; margin-top: 0.25rem; text-transform: uppercase;">CODE MORPHICX</div>
      </div>

      <div class="sidebar-brand" style="cursor: pointer;" onclick="window.navigateTo('landing')">
        <div class="brand-icon">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
            <rect x="2" y="5" width="20" height="14" rx="3" />
            <line x1="2" y1="10" x2="22" y2="10" />
          </svg>
        </div>
        <span class="brand-name">Finance<span>Flow</span></span>
      </div>

      <nav class="sidebar-nav">
        ${navItems.map(item => `
          <div class="nav-item ${activeRoute === item.id ? 'active' : ''}" onclick="window.navigateTo('${item.id}')">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              ${item.icon}
            </svg>
            <span>${item.label}</span>
          </div>
        `).join('')}
      </nav>

      <div class="sidebar-footer">
        <div class="nav-item" style="color: var(--danger); cursor: pointer;" onclick="window.handleLogout()">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/>
          </svg>
          <span>Log Out</span>
        </div>
      </div>
    </aside>
  `;
};

const renderHeader = (store, activeRoute) => {
  const titles = {
    dashboard: 'Dashboard',
    expenses: 'Expenses',
    budget: 'Budget Planner',
    analytics: 'Analytics',
    savings: 'Savings Goals',
    settings: 'Settings'
  };

  const user = store.user || {
    firstName: 'User',
    lastName: '',
    email: 'user@financeflow.com',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=250'
  };

  return `
    <header class="header">
      <div class="header-title">${titles[activeRoute] || 'Dashboard'}</div>

      <div class="header-actions">
        <div class="search-box">
          <span class="search-icon">🔍</span>
          <input type="text" placeholder="Search transactions..." onkeyup="
            if (event.key === 'Enter') {
              alert('Searching for: ' + this.value);
            }
          " />
        </div>

        <button class="icon-btn" title="Toggle Theme" onclick="
          const html = document.documentElement;
          const next = html.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
          html.setAttribute('data-theme', next);
        ">
          🌙
        </button>

        <button class="icon-btn" onclick="alert('You have no new notifications.')">
          🔔
        </button>

        <div class="user-profile" onclick="window.navigateTo('settings')">
          <img src="${user.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=250'}" alt="User Avatar" class="avatar" />
          <div class="user-info">
            <span class="user-name">${user.firstName} ${user.lastName}</span>
            <span class="user-email">${user.email}</span>
          </div>
          <span style="font-size: 0.75rem; color: var(--text-muted);">▼</span>
        </div>
      </div>
    </header>
  `;
};

const renderApp = () => {
  const app = document.getElementById('app');
  const store = getStore();

  // Guard protected routes
  const protectedRoutes = ['dashboard', 'expenses', 'budget', 'analytics', 'savings', 'settings'];
  if (protectedRoutes.includes(currentRoute) && !api.getToken()) {
    currentRoute = 'auth';
  }

  if (currentRoute === 'landing') {
    app.innerHTML = renderLandingPage();
    return;
  }

  if (currentRoute === 'auth') {
    app.innerHTML = renderAuthPage();
    bindAuthEvents();
    return;
  }

  // Internal Views Shell Layout
  let pageContent = '';
  switch (currentRoute) {
    case 'dashboard':
      pageContent = renderDashboardView(store);
      break;
    case 'expenses':
      pageContent = renderExpensesView(store);
      break;
    case 'budget':
      pageContent = renderBudgetPlannerView(store);
      break;
    case 'analytics':
      pageContent = renderAnalyticsView(store);
      break;
    case 'savings':
      pageContent = renderSavingsGoalsView(store);
      break;
    case 'settings':
      pageContent = renderSettingsView(store);
      break;
    default:
      pageContent = renderDashboardView(store);
  }

  app.innerHTML = `
    <div class="app-container">
      ${renderSidebar(currentRoute)}
      <div class="main-content">
        ${renderHeader(store, currentRoute)}
        ${pageContent}
      </div>
    </div>
    ${renderModals()}
  `;

  // Bind view & chart interactions
  bindModalEvents(() => renderApp());
  bindChartInteractivity();

  if (currentRoute === 'expenses') bindExpensesEvents(() => renderApp());
  if (currentRoute === 'settings') bindSettingsEvents();
};

// Listen to store updates
subscribeStore(() => renderApp());

// Initialize app on load & sync remote data if authenticated
document.addEventListener('DOMContentLoaded', async () => {
  if (api.getToken()) {
    await fetchRemoteData();
  }
  renderApp();
});
